﻿
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour {

    public Transform player;
    public Text scoreText;
    public float position;
	
	// Update is called once per frame
	void Update () {
        position = player.position.z + 45f;
        scoreText.text = position.ToString("0");
	}
}
